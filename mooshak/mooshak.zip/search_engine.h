#include "basictechniques.h"

stack *DFS_manager(list *isla_list, map* got_map);
bool check_for_allconnected(list *isla_list);
bool is_connectable(isla *, isla *, int, stack *);

